package edu.csi5230.sshresth.tictactoe;

/**
 * Created by shova on 11/11/2017.
 */

public interface Observer {
    void update(int i);
}
