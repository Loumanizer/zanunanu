package edu.csi5230.sshresth.collegelibrarysystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListofStudents extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listof_students);
    }
}
