package edu.cse523.npatel.learningorm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import java.util.List;

public class ManageRunsActivity extends AppCompatActivity {
    Spinner gameSpinner = null, playerSpinner = null;
    List<Game> games = null;
    List<Player> players = null;
    ArrayAdapter<Game> gameSpinnerAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_runs);

        gameSpinner = findViewById(R.id.spinnerGame);
        playerSpinner = findViewById(R.id.spinnerPlayer);

        games = Game.getAllGames();
        gameSpinnerAdapter = new ArrayAdapter<Game>(this, android.R.layout.simple_list_item_1, games);
        gameSpinner.setAdapter(gameSpinnerAdapter);

    }
}
