package molly.shrestha.edu.oakland.tictactoe;

public interface Observer {
    void update(int i);
}
